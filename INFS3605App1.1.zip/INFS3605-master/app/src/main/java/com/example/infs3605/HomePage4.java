package com.example.infs3605;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class HomePage4 extends AppCompatActivity {

    private Button award;
    private Button leaderboardButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page4);
        Toast.makeText(getApplicationContext(), "New Award Unlocked: Term 1 Completed",Toast.LENGTH_SHORT).show();

        award = findViewById(R.id.award);
        award.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAwards();
            }
        });

        leaderboardButton = findViewById(R.id.leaderboardButton);
        leaderboardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openTempLeaderBoard();
            }
        });

    }
    public void openAwards(){
        Intent intent = new Intent(this, awards.class);
        startActivity(intent);
    }

    public void openTempLeaderBoard(){
        Intent intent = new Intent(this, TempLeaderBoard.class);
        startActivity(intent);
    }
}

